package com.example.shelflyfe

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Displays a real, searchable inventory grid, rather than hard-coded demo cards. */
class InventoryActivity : AppCompatActivity() {
    private lateinit var database: ShelfLyfeDatabase
    private lateinit var grid: GridLayout
    private lateinit var searchField: EditText
    private var userId = -1L
    private var categoryFilter = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)
        database = ShelfLyfeDatabase(this)
        userId = intent.getLongExtra(EXTRA_USER_ID, -1L)
        if (userId <= 0L) { finish(); return }

        val username = intent.getStringExtra(EXTRA_USERNAME).orEmpty()
        findViewById<TextView>(R.id.textGreeting).text = "Welcome, ${username.take(30)}"
        grid = findViewById(R.id.gridInventory)
        searchField = findViewById(R.id.editSearchInventory)
        findViewById<Button>(R.id.buttonAddItem).setOnClickListener { openEditor(-1L) }
        findViewById<TextView>(R.id.navAlerts).setOnClickListener { openAlerts() }
        findViewById<TextView>(R.id.navSettings).setOnClickListener { openAlerts() }
        findViewById<TextView>(R.id.navHome).setOnClickListener {
            categoryFilter = "All"
            searchField.text.clear()
            renderItems()
        }
        findViewById<TextView>(R.id.navInventory).setOnClickListener {
            categoryFilter = "All"
            searchField.text.clear()
            renderItems()
        }
        for ((id, value) in listOf(
            R.id.filterAll to "All", R.id.filterElectronics to "Electronics",
            R.id.filterSupplies to "Supplies", R.id.filterOffice to "Office"
        )) {
            findViewById<Button>(id).setOnClickListener {
                categoryFilter = value
                updateFilterButtons()
                renderItems()
            }
        }
        searchField.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderItems()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        // Wait until the grid has a measured width before sizing two-column cards.
        grid.post { renderItems() }
    }

    override fun onResume() {
        super.onResume()
        if (userId > 0) grid.post { renderItems() }
    }

    private fun renderItems() {
        if (!::grid.isInitialized || userId <= 0L) return
        val allItems = database.inventoryFor(userId)
        findViewById<TextView>(R.id.textTotalItems).text = allItems.size.toString()
        findViewById<TextView>(R.id.textLowStock).text =
            allItems.count { it.quantity in 1..5 }.toString()
        findViewById<TextView>(R.id.textOutOfStock).text =
            allItems.count { it.quantity == 0 }.toString()
        val term = searchField.text.toString().trim()
        val visibleItems = allItems.filter { item ->
            (categoryFilter == "All" || item.category.equals(categoryFilter, ignoreCase = true)) &&
                (term.isEmpty() || item.name.contains(term, ignoreCase = true) ||
                    item.sku.contains(term, ignoreCase = true))
        }
        val empty = findViewById<TextView>(R.id.textEmptyInventory)
        empty.visibility = if (visibleItems.isEmpty()) View.VISIBLE else View.GONE
        empty.text = if (allItems.isEmpty()) "No items yet. Tap Add Item to get started." else
            "No items match your search or category."
        grid.removeAllViews()
        val cardWidth = ((if (grid.width > 0) grid.width else resources.displayMetrics.widthPixels - dp(40))
            - dp(24)) / 2
        for (item in visibleItems) {
            val card = makeItemCard(item)
            val params = GridLayout.LayoutParams().apply {
                width = cardWidth.coerceAtLeast(dp(130))
                height = GridLayout.LayoutParams.WRAP_CONTENT
                setMargins(0, 0, dp(12), dp(12))
            }
            grid.addView(card, params)
        }
        updateFilterButtons()
    }

    private fun makeItemCard(item: InventoryItem): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.WHITE)
            elevation = dp(2).toFloat()
        }
        card.addView(text(item.name, 16f, "#101828", true))
        card.addView(text("SKU: ${item.sku}", 12f, "#667085"))
        card.addView(text(item.category, 12f, "#667085"))
        card.addView(text("Quantity: ${item.quantity}", 14f, "#344054", true).apply {
            setPadding(0, dp(10), 0, dp(3))
        })
        val label = when {
            item.quantity == 0 -> "● Out of Stock"
            item.quantity <= 5 -> "● Low Stock"
            else -> "● In Stock"
        }
        val color = when {
            item.quantity == 0 -> "#D92D20"
            item.quantity <= 5 -> "#B26A00"
            else -> "#128A3E"
        }
        card.addView(text(label, 12f, color, true))
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        val minus = smallButton("−", "#E8F1FF", "#1473E6")
        minus.contentDescription = "Decrease quantity of ${item.name}"
        minus.setOnClickListener { changeQuantity(item, -1) }
        val plus = smallButton("+", "#E8F1FF", "#1473E6")
        plus.contentDescription = "Increase quantity of ${item.name}"
        plus.setOnClickListener { changeQuantity(item, 1) }
        controls.addView(minus, LinearLayout.LayoutParams(0, dp(44), 1f))
        controls.addView(plus, LinearLayout.LayoutParams(0, dp(44), 1f))
        card.addView(controls)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val edit = smallButton("Edit", "#E8F1FF", "#1473E6")
        edit.setOnClickListener { openEditor(item.id) }
        val delete = smallButton("Delete", "#FDEBEC", "#D92D20")
        delete.setOnClickListener { confirmDelete(item) }
        actions.addView(edit, LinearLayout.LayoutParams(-1, dp(42)))
        actions.addView(delete, LinearLayout.LayoutParams(-1, dp(42)))
        card.addView(actions)
        return card
    }

    private fun changeQuantity(item: InventoryItem, delta: Int) {
        if (delta < 0 && item.quantity == 0) return
        if (delta > 0 && item.quantity == Int.MAX_VALUE) return
        val newQuantity = item.quantity + delta
        val updated = database.saveItem(userId, item.copy(quantity = newQuantity))
        if (updated) {
            if (item.quantity > 0 && newQuantity == 0) {
                SmsAlerts.notifyOutOfStock(this, userId, item.name)
            }
            renderItems()
        } else {
            android.widget.Toast.makeText(this, "Could not update quantity", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDelete(item: InventoryItem) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${item.name}?")
            .setMessage("This will permanently remove the item from your inventory.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                database.deleteItem(userId, item.id)
                renderItems()
            }.show()
    }

    private fun openEditor(itemId: Long) {
        startActivity(Intent(this, AddItemActivity::class.java).apply {
            putExtra(EXTRA_USER_ID, userId)
            putExtra(AddItemActivity.EXTRA_ITEM_ID, itemId)
        })
    }

    private fun openAlerts() {
        startActivity(Intent(this, AlertsActivity::class.java).apply {
            putExtra(EXTRA_USER_ID, userId)
        })
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(12).toFloat()
    }

    private fun text(content: String, size: Float, hex: String, bold: Boolean = false) = TextView(this).apply {
        text = content
        textSize = size
        setTextColor(Color.parseColor(hex))
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun smallButton(label: String, bg: String, fg: String) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.parseColor(fg))
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(bg))
        minHeight = dp(40)
        minWidth = 0
        minimumWidth = 0
        setPadding(0, 0, 0, 0)
    }

    private fun updateFilterButtons() {
        for ((id, value) in listOf(
            R.id.filterAll to "All", R.id.filterElectronics to "Electronics",
            R.id.filterSupplies to "Supplies", R.id.filterOffice to "Office"
        )) {
            val active = value == categoryFilter
            findViewById<Button>(id).apply {
                setTextColor(Color.parseColor(if (active) "#FFFFFF" else "#344054"))
                backgroundTintList = android.content.res.ColorStateList.valueOf(
                    Color.parseColor(if (active) "#1473E6" else "#E8EDF5"))
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        const val EXTRA_USER_ID = "com.example.shelflyfe.USER_ID"
        const val EXTRA_USERNAME = "com.example.shelflyfe.USERNAME"
    }
}
