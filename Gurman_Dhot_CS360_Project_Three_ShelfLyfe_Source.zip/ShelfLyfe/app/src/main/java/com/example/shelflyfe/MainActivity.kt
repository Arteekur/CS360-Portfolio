package com.example.shelflyfe

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Login and registration share the existing Project Two screen design. */
class MainActivity : AppCompatActivity() {
    private lateinit var database: ShelfLyfeDatabase
    private lateinit var username: EditText
    private lateinit var password: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        database = ShelfLyfeDatabase(this)
        username = findViewById(R.id.editUsername)
        password = findViewById(R.id.editPassword)

        findViewById<Button>(R.id.buttonLogin).setOnClickListener {
            val name = username.text.toString().trim()
            val pass = password.text.toString()
            if (name.isEmpty() || pass.isEmpty()) {
                toast("Please enter your username and password.")
                return@setOnClickListener
            }
            val userId = database.authenticate(name, pass)
            if (userId == null) {
                password.error = "Incorrect username or password"
                toast("Incorrect username or password.")
            } else {
                password.text.clear()
                startActivity(Intent(this, InventoryActivity::class.java).apply {
                    putExtra(InventoryActivity.EXTRA_USER_ID, userId)
                    putExtra(InventoryActivity.EXTRA_USERNAME, name)
                })
            }
        }
        findViewById<Button>(R.id.buttonCreateAccount).setOnClickListener {
            val name = username.text.toString().trim()
            val pass = password.text.toString()
            when {
                name.length < 3 -> username.error = "Use at least 3 characters"
                name.length > 40 -> username.error = "Username is too long"
                pass.length < 8 -> password.error = "Use at least 8 characters"
                else -> {
                    val id = database.register(name, pass)
                    if (id == null) {
                        username.error = "That username already exists"
                    } else {
                        password.text.clear()
                        AlertDialog.Builder(this)
                            .setTitle("Account created!")
                            .setMessage("Your ShelfLyfe account is ready. Sign in to get started.")
                            .setPositiveButton("Got it", null)
                            .show()
                    }
                }
            }
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
