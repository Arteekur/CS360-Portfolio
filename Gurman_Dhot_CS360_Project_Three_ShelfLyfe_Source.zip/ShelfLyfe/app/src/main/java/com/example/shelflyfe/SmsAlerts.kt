package com.example.shelflyfe

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SmsManager
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat

/** Only send after explicit opt-in, permission grant, and a positive-to-zero stock change. */
object SmsAlerts {
    private const val PREFS = "shelflyfe_alert_settings"
    // Consent and alert numbers belong to a user, not to everyone sharing the device.
    private fun enabledKey(userId: Long) = "sms_enabled_$userId"
    private fun phoneKey(userId: Long) = "sms_phone_$userId"

    fun isEnabled(context: Context, userId: Long): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(enabledKey(userId), false)

    fun savedPhone(context: Context, userId: Long): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(phoneKey(userId), "").orEmpty()

    fun setEnabled(context: Context, userId: Long, enabled: Boolean,
                   phone: String = savedPhone(context, userId)) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(enabledKey(userId), enabled)
            .putString(phoneKey(userId), phone)
            .apply()
    }

    fun validPhone(phone: String): Boolean = Regex("^\\+?[0-9]{7,15}$")
        .matches(phone.replace(Regex("[\\s()\\-]"), ""))

    /** Called after a persisted stock change from greater than 0 to exactly 0. */
    fun notifyOutOfStock(context: Context, userId: Long, itemName: String) {
        if (userId <= 0 || !isEnabled(context, userId)) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) !=
            PackageManager.PERMISSION_GRANTED) return
        if (!context.packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING)) return
        val phone = savedPhone(context, userId)
        if (!validPhone(phone)) return
        val cleanPhone = phone.replace(Regex("[\\s()\\-]"), "")
        val message = "ShelfLyfe alert: $itemName is out of stock (quantity 0)."
        try {
            @Suppress("DEPRECATION")
            SmsManager.getDefault().sendTextMessage(cleanPhone, null, message, null, null)
            Toast.makeText(context, "Stock alert submitted to SMS service", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            // A device may have no SIM/subscription, including some emulator images.
            Log.w("ShelfLyfeSMS", "Unable to send SMS", e)
            Toast.makeText(context, "SMS couldn't be sent on this device", Toast.LENGTH_LONG).show()
        }
    }
}
