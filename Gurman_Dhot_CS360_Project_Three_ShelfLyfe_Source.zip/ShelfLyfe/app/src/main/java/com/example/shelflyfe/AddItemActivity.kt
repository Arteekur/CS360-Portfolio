package com.example.shelflyfe

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Add and edit use the existing entry form and the same SQLite table. */
class AddItemActivity : AppCompatActivity() {
    private lateinit var database: ShelfLyfeDatabase
    private var userId = -1L
    private var itemId = -1L
    private var previousQuantity: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)
        database = ShelfLyfeDatabase(this)
        userId = intent.getLongExtra(InventoryActivity.EXTRA_USER_ID, -1L)
        itemId = intent.getLongExtra(EXTRA_ITEM_ID, -1L)
        if (userId <= 0) { finish(); return }

        val name = findViewById<EditText>(R.id.editItemName)
        val sku = findViewById<EditText>(R.id.editSku)
        val category = findViewById<EditText>(R.id.editCategory)
        val quantity = findViewById<EditText>(R.id.editQuantity)
        if (itemId > 0) {
            val item = database.findItem(userId, itemId)
            if (item == null) { finish(); return }
            name.setText(item.name)
            sku.setText(item.sku)
            category.setText(item.category)
            quantity.setText(item.quantity.toString())
            previousQuantity = item.quantity
            // The original UI label is 'Add Inventory Item'; change it for an edit.
            val root = findViewById<android.view.ViewGroup>(android.R.id.content)
            changeHeading(root, "Add Inventory Item", "Edit Inventory Item")
        }

        findViewById<Button>(R.id.buttonSaveItem).setOnClickListener {
            val itemName = name.text.toString().trim()
            val itemSku = sku.text.toString().trim()
            val itemCategory = category.text.toString().trim()
            val itemQty = quantity.text.toString().toIntOrNull()
            when {
                itemName.isEmpty() -> name.error = "Item name is required"
                itemSku.isEmpty() -> sku.error = "SKU is required"
                itemQty == null || itemQty < 0 -> quantity.error = "Enter a valid quantity (0 or higher)"
                else -> {
                    val saved = database.saveItem(userId, InventoryItem(
                        itemId, itemName, itemSku, itemCategory.ifBlank { "Other" }, itemQty
                    ))
                    if (!saved) {
                        sku.error = "This SKU may already exist"
                        Toast.makeText(this, "Could not save item. Check the SKU.", Toast.LENGTH_LONG).show()
                    } else {
                        // Alert when stock changes from positive to zero, including manual edits.
                        if (previousQuantity != null && previousQuantity!! > 0 && itemQty == 0) {
                            SmsAlerts.notifyOutOfStock(this, userId, itemName)
                        }
                        Toast.makeText(this, "Item saved successfully", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }
            }
        }
        findViewById<Button>(R.id.buttonCancelItem).setOnClickListener { finish() }
    }

    private fun changeHeading(root: android.view.ViewGroup, original: String, replacement: String) {
        for (i in 0 until root.childCount) {
            when (val child = root.getChildAt(i)) {
                is TextView -> if (child.text.toString() == original) child.text = replacement
                is android.view.ViewGroup -> changeHeading(child, original, replacement)
            }
        }
    }

    companion object { const val EXTRA_ITEM_ID = "com.example.shelflyfe.ITEM_ID" }
}
