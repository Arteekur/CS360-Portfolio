package com.example.shelflyfe

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** SMS is optional: denied permission never disables inventory management. */
class AlertsActivity : AppCompatActivity() {
    private var userId = -1L
    private lateinit var phoneField: EditText
    private lateinit var enableButton: Button
    private lateinit var status: TextView

    private val requestSmsPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            SmsAlerts.setEnabled(this, userId, true, phoneField.text.toString().trim())
            toast("SMS alerts enabled")
        } else {
            SmsAlerts.setEnabled(this, userId, false)
            toast("Permission denied. Inventory still works without SMS.")
        }
        updateStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alerts)
        userId = intent.getLongExtra(InventoryActivity.EXTRA_USER_ID, -1L)
        if (userId <= 0L) { finish(); return }
        phoneField = findViewById(R.id.editPhoneNumber)
        enableButton = findViewById(R.id.buttonEnableSms)
        status = findViewById(R.id.textSmsStatus)
        phoneField.setText(SmsAlerts.savedPhone(this, userId))
        enableButton.setOnClickListener {
            if (SmsAlerts.isEnabled(this, userId)) {
                SmsAlerts.setEnabled(this, userId, false)
                toast("SMS alerts disabled")
                updateStatus()
            } else {
                val phone = phoneField.text.toString().trim()
                if (!SmsAlerts.validPhone(phone)) {
                    phoneField.error = "Enter a valid number (e.g., +12145550123)"
                    return@setOnClickListener
                }
                if (!packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING)) {
                    toast("This emulator/device cannot send SMS. Inventory still works.")
                    updateStatus()
                    return@setOnClickListener
                }
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
                    PackageManager.PERMISSION_GRANTED) {
                    SmsAlerts.setEnabled(this, userId, true, phone)
                    toast("SMS alerts enabled")
                    updateStatus()
                } else {
                    requestSmsPermission.launch(Manifest.permission.SEND_SMS)
                }
            }
        }
        findViewById<Button>(R.id.buttonBackInventory).setOnClickListener { finish() }
        updateStatus()
    }

    private fun updateStatus() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
            PackageManager.PERMISSION_GRANTED
        val enabled = SmsAlerts.isEnabled(this, userId) && granted
        status.text = when {
            enabled -> "Enabled • Out-of-stock SMS will go to ${SmsAlerts.savedPhone(this, userId)}"
            !granted -> "SMS permission not granted. Alerts are disabled."
            else -> "SMS alerts are currently disabled."
        }
        enableButton.text = if (enabled) "Disable SMS Notifications" else "Enable SMS Notifications"
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
