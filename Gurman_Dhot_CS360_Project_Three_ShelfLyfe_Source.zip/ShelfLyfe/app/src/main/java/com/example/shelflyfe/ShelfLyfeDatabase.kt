package com.example.shelflyfe

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** One local SQLite database for registered users and their inventory items. */
class ShelfLyfeDatabase(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "shelflyfe.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL COLLATE NOCASE UNIQUE,
                salt TEXT NOT NULL,
                password_hash TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                sku TEXT NOT NULL,
                category TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK (quantity >= 0),
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, sku),
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_inventory_owner ON inventory(user_id)")
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1 is the initial release; future migrations belong here.
        // Never silently drop users' inventory during a schema upgrade.
    }

    /** Returns the new user ID or null when the username is already taken. */
    fun register(username: String, password: String): Long? {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val algorithm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            "PBKDF2WithHmacSHA256"
        } else {
            "PBKDF2WithHmacSHA1"
        }
        val values = ContentValues().apply {
            put("username", username.trim())
            put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            put("password_hash", "$algorithm:${derivePassword(password, salt, algorithm)}")
        }
        return try {
            writableDatabase.insertOrThrow("users", null, values)
        } catch (_: SQLiteConstraintException) {
            null
        }
    }

    /** Checks the password using a slow salted hash and constant-time comparison. */
    fun authenticate(username: String, password: String): Long? {
        readableDatabase.query(
            "users", arrayOf("id", "salt", "password_hash"),
            "username = ?", arrayOf(username.trim()), null, null, null
        ).use { cursor ->
            if (!cursor.moveToFirst()) return null
            val id = cursor.getLong(0)
            val salt = Base64.decode(cursor.getString(1), Base64.NO_WRAP)
            val stored = cursor.getString(2)
            val index = stored.indexOf(':')
            if (index <= 0) return null
            val algorithm = stored.substring(0, index)
            if (algorithm != "PBKDF2WithHmacSHA256" && algorithm != "PBKDF2WithHmacSHA1") return null
            val candidate = derivePassword(password, salt, algorithm)
            val savedHash = Base64.decode(stored.substring(index + 1), Base64.NO_WRAP)
            val inputHash = Base64.decode(candidate, Base64.NO_WRAP)
            return if (MessageDigest.isEqual(savedHash, inputHash)) id else null
        }
    }

    fun inventoryFor(userId: Long): List<InventoryItem> {
        val result = mutableListOf<InventoryItem>()
        readableDatabase.query(
            "inventory", arrayOf("id", "name", "sku", "category", "quantity"),
            "user_id = ?", arrayOf(userId.toString()), null, null, "name COLLATE NOCASE ASC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result.add(InventoryItem(
                    cursor.getLong(0), cursor.getString(1), cursor.getString(2),
                    cursor.getString(3), cursor.getInt(4)
                ))
            }
        }
        return result
    }

    fun findItem(userId: Long, itemId: Long): InventoryItem? {
        readableDatabase.query(
            "inventory", arrayOf("id", "name", "sku", "category", "quantity"),
            "user_id = ? AND id = ?", arrayOf(userId.toString(), itemId.toString()),
            null, null, null
        ).use { cursor ->
            if (!cursor.moveToFirst()) return null
            return InventoryItem(cursor.getLong(0), cursor.getString(1),
                cursor.getString(2), cursor.getString(3), cursor.getInt(4))
        }
    }

    /** Returns false for duplicate SKUs or invalid data. */
    fun saveItem(userId: Long, item: InventoryItem): Boolean {
        if (userId <= 0 || item.name.isBlank() || item.sku.isBlank() || item.quantity < 0) return false
        val values = ContentValues().apply {
            put("name", item.name.trim())
            put("sku", item.sku.trim().uppercase())
            put("category", item.category.trim().ifBlank { "Other" })
            put("quantity", item.quantity)
            put("updated_at", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                .format(java.util.Date()))
        }
        return try {
            if (item.id <= 0L) {
                values.put("user_id", userId)
                writableDatabase.insertOrThrow("inventory", null, values) > 0
            } else {
                writableDatabase.update("inventory", values, "id = ? AND user_id = ?",
                    arrayOf(item.id.toString(), userId.toString())) > 0
            }
        } catch (_: SQLiteConstraintException) {
            false
        }
    }

    fun deleteItem(userId: Long, itemId: Long): Boolean =
        writableDatabase.delete("inventory", "id = ? AND user_id = ?",
            arrayOf(itemId.toString(), userId.toString())) > 0

    private fun derivePassword(password: String, salt: ByteArray, algorithm: String): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 150_000, 256)
        return try {
            val bytes = SecretKeyFactory.getInstance(algorithm).generateSecret(spec).encoded
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } finally {
            spec.clearPassword()
        }
    }
}

data class InventoryItem(
    val id: Long = 0L,
    val name: String,
    val sku: String,
    val category: String,
    val quantity: Int
)
