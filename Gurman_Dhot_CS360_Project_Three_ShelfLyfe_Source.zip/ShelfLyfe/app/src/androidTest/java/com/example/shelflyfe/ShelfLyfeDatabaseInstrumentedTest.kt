package com.example.shelflyfe

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Run on an Android Emulator with: ./gradlew connectedDebugAndroidTest */
@RunWith(AndroidJUnit4::class)
class ShelfLyfeDatabaseInstrumentedTest {
    @Test
    fun accountAndInventoryPersistAndRemainUserSpecific() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val database = ShelfLyfeDatabase(context)
        val suffix = System.nanoTime().toString()
        val username = "user_$suffix"
        val otherUsername = "other_$suffix"
        val userId = database.register(username, "SecurePass123!")
        assertNotNull(userId)
        assertEquals(userId, database.authenticate(username, "SecurePass123!"))
        assertNull(database.authenticate(username, "wrong-password"))
        assertNull(database.register(username, "DuplicatePass123!"))

        val otherId = database.register(otherUsername, "AnotherPass123!")
        assertNotNull(otherId)
        assertTrue(database.saveItem(userId!!, InventoryItem(
            name = "Test Battery", sku = "TB-$suffix", category = "Supplies", quantity = 1
        )))
        val stored = database.inventoryFor(userId).single { it.sku == "TB-$suffix" }
        assertEquals(1, stored.quantity)
        assertTrue(database.saveItem(userId, stored.copy(quantity = 0)))
        assertEquals(0, database.findItem(userId, stored.id)?.quantity)
        assertTrue(database.inventoryFor(otherId!!).none { it.sku == "TB-$suffix" })
        database.close()

        val reloaded = ShelfLyfeDatabase(context)
        assertEquals(0, reloaded.findItem(userId, stored.id)?.quantity)
        assertTrue(reloaded.deleteItem(userId, stored.id))
        assertNull(reloaded.findItem(userId, stored.id))
        reloaded.close()
    }
}
