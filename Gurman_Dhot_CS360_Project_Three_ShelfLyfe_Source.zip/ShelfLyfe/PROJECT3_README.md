# ShelfLyfe — CS 360 Project Three

Project type: **Option 1 / Inventory App**  
Language: **Kotlin + XML** (matching the Project Two starter project)  
Package: `com.example.shelflyfe`

## What's implemented in this version

- Log in and create a separate local user account (validated against SQLite)
- Password storage using a random 16-byte salt and an iterated PBKDF2 password hash
- Local SQLite tables for users and their own inventory records
- Inventory displayed in a two-column grid with accurate summary counts
- Add, edit, delete (with confirmation), increment and decrement item quantities
- Search by item name or SKU; filter by category
- Save inventory changes across app closures/restarts
- Opt-in out-of-stock SMS, with a phone-number field and a runtime permission request
- App remains fully usable without SMS permission or messaging-capable hardware
- User-specific SMS preferences, so a second account does not inherit another user's opt-in
- Custom blue-and-white shelf launcher icon, based on the existing UI colors
- Instrumentation test source for authentication and database persistence

## Opening the project in Android Studio

1. Extract `ShelfLyfe` from the ZIP to a normal folder.
2. Choose **File > Open** and select the **ShelfLyfe** folder containing `settings.gradle.kts`.
3. Allow **Gradle Sync** to finish. If the IDE requests an Android SDK, install **API 37** in **Tools > SDK Manager**. The original project uses Gradle 9.6.0 / Android Gradle Plugin 9.4.1.
4. Choose **Build > Make Project**. Fix any IDE/version errors before continuing.
5. Choose an Android emulator/device and press **Run**.
6. To build an optional APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Note: The supplied ZIP contains **source code**, not a compiled APK. Android SDK and emulator binaries were not available in the editing environment; the code has **not yet been compiled or device-tested** here. You must run the build and emulator checks before calling this ready to submit.

## Manual emulator testing checklist

- [ ] Create account `tester1` with an 8+-character password; observe success message
- [ ] Reject a wrong login; accept correct login
- [ ] Add `Mouse`, SKU `M-001`, Electronics, quantity 2
- [ ] Search for Mouse and use the Electronics category filter
- [ ] Tap `+` then `−`; verify counters change
- [ ] Edit the item's name/category/quantity and verify the changes stick
- [ ] Add a second item and delete it; verify deletion confirmation and list refresh
- [ ] Close/relaunch the app and sign in again; verify saved inventory is still present
- [ ] Register a second username; verify its inventory starts empty
- [ ] Open Alerts, enter a test destination phone number, tap Enable, and **deny** SMS permission. Verify inventory continues to work.
- [ ] For the granted path, enable SMS permission on an emulator/device **with telephony support**; reducing an existing item's quantity from 1 to 0 should submit an SMS. Test on a controlled destination number only (an emulator pair is ideal). Sending depends on device/carrier/emulator support.
- [ ] Ensure no alert is attempted for stock changing from 0 to 1 or 2 to 1
- [ ] Disable SMS and verify no SMS is attempted when another item reaches 0
- [ ] Rotate the emulator and test a narrower/large screen to inspect card sizing

Database instrumentation tests can be run with a connected emulator using `gradlew.bat connectedDebugAndroidTest` on Windows.

## Important: Google Play distribution

The course rubric requires SMS. However, Google's Play Store generally restricts `SEND_SMS` to approved default handlers/exceptions. This implementation is for the coursework/testing scenario; public release would need a policy review and may need to replace SMS with in-app or local notifications.

## Submission items

- `ShelfLyfe_CS360_Project_Three_Source.zip` — this complete source project
- `Gurman_Dhot_CS360_Project_Three_ShelfLyfe_Launch_Plan.docx` — separate Word launch plan

After testing, capture screenshots showing successful emulator flows and any permission prompt. The instructor can compile the ZIP, or you may additionally build and attach an APK if requested.
